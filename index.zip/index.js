const express = require("express");
const productRoutes = require("./product.route.js");
const app = express();
const port = process.env.PORT || 3000;

app.get("/", (req, res) => {
  res.send("My name is Admin");
})

app.use( (req, res, next ) => {
  res.setHeader('content-Type', 'application/json; charset=utf-8');
  next();
});
app.use("/products", productRoutes);

app.listen(port, () => {
  console.log(`Example app listening on port ${port}`)
})

module.exports = app;